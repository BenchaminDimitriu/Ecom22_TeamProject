<?php

echo Locale::getDefault();

?>

