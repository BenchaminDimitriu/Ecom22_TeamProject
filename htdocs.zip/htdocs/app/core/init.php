<?php
	session_start();
	define('BASE', '/');
	require("app/core/autoload.php");
	require("app/core/phpqrcode/qrlib.php");

